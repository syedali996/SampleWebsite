
# Operation Type Enum

Possible operators are sum, subtract, multiply, divide

## Enumeration

`OperationTypeEnum`

## Fields

| Name | Description |
|  --- | --- |
| `sUM` | Represents the sum operator |
| `sUBTRACT` | Represents the subtract operator |
| `mULTIPLY` | Represents the multiply operator |
| `dIVIDE` | Represents the divide operator |


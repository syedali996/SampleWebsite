
# Operation Type Enum

Possible operators are sum, subtract, multiply, divide

## Enumeration

`OperationTypeEnum`

## Fields

| Name | Description |
|  --- | --- |
| `SUM` | Represents the sum operator |
| `SUBTRACT` | Represents the subtract operator |
| `MULTIPLY` | Represents the multiply operator |
| `DIVIDE` | Represents the divide operator |

